package com.willmd.wangytool;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.emoji.bundled.BundledEmojiCompatConfig;
import androidx.emoji.text.EmojiCompat;
import androidx.emoji.widget.EmojiAppCompatEditText;
import androidx.emoji.widget.EmojiAppCompatTextView;
import androidx.emoji.widget.EmojiEditText;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
//    private static final String LOVE = "\u2764\ufe0f";

    private EmojiAppCompatEditText edit1, edit2;
    private Button bt1, bt2;
    private TextView tv1;
    private EmojiAppCompatTextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EmojiCompat.Config config = new BundledEmojiCompatConfig(this);
        EmojiCompat.init(config);

        edit1 = (EmojiAppCompatEditText) findViewById(R.id.field_nama);
        edit2 = (EmojiAppCompatEditText) findViewById(R.id.hasil);

        textView = (EmojiAppCompatTextView) findViewById(R.id.titles);

        bt1 = (Button) findViewById(R.id.template1);
        bt2 = (Button) findViewById(R.id.salintext);

        tv1 = (TextView) findViewById(R.id.nama_digunakan);

        final String nama = edit1.getText().toString().trim();
        final String hasil = edit2.getText().toString().trim();

        tv1.setText(nama);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit2.setText(nama + " " + nama + " " + nama + " " + "❤️ ❤️ ❤️ WANGI WANGI WANGI WANGI HU HA HU HA HU HA, aaaah baunya rambut " + nama + " wangi aku mau nyiumin aroma wanginya " + nama + " AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~~~ AAAAAH " + nama + " keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH " + nama + " AAAAA LUCCUUUUUUUUUUUUUUU............ " + nama + " AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️ apa ? " + nama + " itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ " + nama + " gw ..." + nama + " di laptop ngeliatin gw, " + nama + " .. kamu percaya sama aku ? aaaaaaaaaaah syukur " + nama + " aku gak mau merelakan " + nama + " aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA " + nama + " SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH'");
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Text", hasil);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(MainActivity.this, "Text Disalin", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initEmojiCompat() {
        EmojiCompat.Config config = new BundledEmojiCompatConfig(this);
        config.setReplaceAll(true)
                .registerInitCallback(new EmojiCompat.InitCallback() {
                    @Override
                    public void onInitialized() {
                        Log.i(TAG, "EmojiCompat initialized");
                    }

                    @Override
                    public void onFailed(@Nullable Throwable throwable) {
                        Log.e(TAG, "EmojiCompat initialization failed", throwable);
                    }
                });
        EmojiCompat.init(config);
    }
}